#!/usr/bin/env python3
"""
ОПТИМІЗОВАНИЙ ПОШУК О-КОДУ

Замість повного брутфорсу:
1. Не грузимо весь словник в пам'ять
2. Перевіряємо чи код містить ключові слова
3. Фільтруємо неможливі комбінації
"""

import itertools
import re

class OptimizedOCodeSearch:
    """Оптимізований пошук О-коду"""
    
    def __init__(self):
        # Ключові слова О-теорії (мають бути в коді)
        self.required_keywords = [
            "О", "1", "!=", "=", 
            "правда", "баланс", "полярність"
        ]
        
        # О-послідовність
        self.O_sequence = [1, 2, 4, 3, 5]
        
        # Лічильник перевірених варіантів
        self.checked = 0
        self.filtered = 0
    
    def has_all_keywords(self, code):
        """Чи містить код всі ключові слова?"""
        # Швидка перевірка без повного парсингу
        for keyword in self.required_keywords:
            if keyword not in code:
                return False
        return True
    
    def has_O_pattern(self, code):
        """Чи містить О-паттерн [1,2,4,3,5]?"""
        # Шукаємо послідовність цифр
        digits = re.findall(r'\d', code)
        
        # Перевіряємо чи є О-послідовність
        seq_str = ''.join(map(str, self.O_sequence))
        code_digits = ''.join(digits)
        
        return seq_str in code_digits
    
    def calculate_O_score(self, code):
        """О-оцінка коду (наскільки він близький до О?)"""
        score = 0
        
        # +1 за кожне ключове слово
        for keyword in self.required_keywords:
            if keyword in code:
                score += 1
        
        # +5 за О-паттерн
        if self.has_O_pattern(code):
            score += 5
        
        # +3 за символ ≠ або !=
        if '!=' in code or '≠' in code:
            score += 3
        
        # +2 за баланс (- і +)
        if '-' in code and '+' in code:
            score += 2
        
        return score
    
    def filter_impossible(self, candidate):
        """Фільтр: чи можливий цей варіант?"""
        # Фільтр 1: Має містити хоч щось
        if len(candidate) < 5:
            self.filtered += 1
            return False
        
        # Фільтр 2: Має містити хоч одне ключове слово
        has_any_keyword = any(k in candidate for k in self.required_keywords[:3])
        if not has_any_keyword:
            self.filtered += 1
            return False
        
        # Фільтр 3: Не може бути тільки числа
        if candidate.isdigit():
            self.filtered += 1
            return False
        
        return True
    
    def smart_search(self, search_space, max_candidates=1000):
        """
        Розумний пошук замість брутфорсу
        
        Args:
            search_space: список можливих елементів
            max_candidates: максимум варіантів для перевірки
        """
        print("🔍 Розпочинаю оптимізований пошук О-коду...")
        print(f"   Простір пошуку: {len(search_space)} елементів")
        print(f"   Макс. кандидатів: {max_candidates}\n")
        
        candidates = []
        
        # Генеруємо комбінації розумно
        for length in range(3, 6):  # Довжина від 3 до 5 елементів
            print(f"Перевірка комбінацій довжини {length}...")
            
            count = 0
            for combo in itertools.permutations(search_space, length):
                candidate = ''.join(str(x) for x in combo)
                
                self.checked += 1
                
                # Швидкий фільтр
                if not self.filter_impossible(candidate):
                    continue
                
                # О-оцінка
                score = self.calculate_O_score(candidate)
                
                if score > 5:  # Тільки перспективні
                    candidates.append({
                        'code': candidate,
                        'score': score,
                        'combo': combo
                    })
                
                count += 1
                if count >= max_candidates:
                    break
            
            if candidates:
                break  # Знайшли щось перспективне
        
        # Сортуємо за О-оцінкою
        candidates.sort(key=lambda x: x['score'], reverse=True)
        
        print(f"\n✅ Перевірено: {self.checked} варіантів")
        print(f"   Відфільтровано: {self.filtered} неможливих")
        print(f"   Знайдено кандидатів: {len(candidates)}\n")
        
        return candidates[:10]  # Топ-10


def test_O_code_search():
    """Тест пошуку О-коду"""
    
    print("="*80)
    print("ОПТИМІЗОВАНИЙ ПОШУК О-КОДУ")
    print("="*80)
    print()
    
    # Простір пошуку (приклад)
    search_space = [
        "О", "1", "2", "4", "3", "5",
        "!=", "=", "-", "+",
        "правда", "баланс"
    ]
    
    searcher = OptimizedOCodeSearch()
    
    # Виконуємо пошук
    results = searcher.smart_search(search_space, max_candidates=1000)
    
    # Виводимо результати
    print("🏆 ТОП КАНДИДАТИ:")
    print("-" * 80)
    
    for i, candidate in enumerate(results, 1):
        print(f"\n{i}. Код: {candidate['code']}")
        print(f"   О-оцінка: {candidate['score']}/15")
        print(f"   Елементи: {candidate['combo']}")
        
        # Аналізуємо
        has_keywords = searcher.has_all_keywords(candidate['code'])
        has_pattern = searcher.has_O_pattern(candidate['code'])
        
        print(f"   Має всі слова: {'✓' if has_keywords else '✗'}")
        print(f"   Має О-паттерн: {'✓' if has_pattern else '✗'}")
    
    # Рекомендації
    print("\n" + "="*80)
    print("РЕКОМЕНДАЦІЇ ДЛЯ ПОКРАЩЕННЯ ПОШУКУ")
    print("="*80)
    print("""
1. ФІЛЬТР ЗА СТРУКТУРОЮ:
   • Код має містити оператор (=, !=, -, +)
   • Код має містити числа (1,2,4,3,5)
   • Код має містити концепцію (О, правда, баланс)

2. ФІЛЬТР ЗА СИНТАКСИСОМ:
   • Математично валідний вираз
   • Логічно когерентний
   • Філософськи осмислений

3. ФІЛЬТР ЗА О-ВІДПОВІДНІСТЮ:
   • Чи містить О-послідовність [1,2,4,3,5]?
   • Чи виражає полярність (-1 О 1)?
   • Чи має балансну структуру?

4. ЕВРИСТИКИ:
   • Код довжиною 10-20 символів (оптимум)
   • Містить не більше 3 операторів
   • Баланс символів: 50% числа, 30% оператори, 20% слова

ПРИКЛАД ІДЕАЛЬНОГО О-КОДУ:
   "1!=1 → О-баланс(-1⭕1)"
   
   Чому ідеальний:
   • Містить 1!=1 (основна концепція)
   • Містить О (символ)
   • Містить баланс (концепція)
   • Містить полярність (-1, 1)
   • Довжина: оптимальна
   • Читабельність: висока
""")


if __name__ == "__main__":
    test_O_code_search()
